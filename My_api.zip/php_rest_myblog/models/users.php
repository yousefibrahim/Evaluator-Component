<?php
  class users {
    // DB Stuff
    private $conn;
    private $table = 'users';

    // Properties
    public $id;
    public $name;
    public $email;
    public $gender;
    public $dob;
    public $interest_1;
    public $interest_2;
    public $interest_3;
    public $interest_4;
    public $interest_5;
    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Get categories
    public function read() {
      // Create query
      $query = 'SELECT DISTINCT c.id, c.name,c.email,c.gender,c.dob, c.interest_1,c.interest_2,c.interest_3,c.interest_4,c.interest_5 
                                FROM ' . $this->table . ' c
                                JOIN
                                company p ON p.interest1=c.interest_1
                                OR p.interest2 = c.interest_2  
                                OR p.interest3 = c.interest_3  
                                OR p.interest4 = c.interest_4
                                OR p.interest5 = c.interest_5
                                ORDER BY 
                                c.interest_1 ASC
                                ';
      
                                
      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    

    

  

  

  
  }
