<?php 
  class Quiz {
    // DB stuff
    private $conn;
    private $table = 'quiz';

    // Post Properties
    public $QuizId;
    public $QuizTitle;
    public $QuizDescription;
    public $TotalScore;
    public $Duration;
    public $CompanyId;
    public $Rate;
    public $Numof_participant;
    // Constructor with DB
    public function __construct($db) {
      $this->conn = $db;
    }

    // Get Posts
    public function read() {
      // Create query
      $query = 'SELECT DISTINCT p.QuizId, p.QuizTitle, p.QuizDescription, p.CompanyId
                                FROM ' . $this->table . ' p
                                JOIN company q ON q.companyID = p.CompanyId';
      
      // Prepare statement
      $stmt = $this->conn->prepare($query);

      // Execute query
      $stmt->execute();

      return $stmt;
    }

    
  }